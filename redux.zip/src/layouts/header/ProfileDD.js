import React from 'react';// eslint-disable-next-line
import Avatar from 'react-avatar';
import { DropdownItem } from 'reactstrap';
import { User } from 'react-feather';
import { connect } from 'react-redux';
// import user1 from '../../assets/images/users/user1.jpg';




const mapStateToProps = (state) => ({
  profile: state.loginReducer.profile,
})

const ProfileDD = (props) => {
  console.log("username :", props.profile.userName)
  return (
    <div>
      <div className="d-flex gap-3 p-3 border-bottom pt-2 align-items-center">
        {/* <img src={user1} alt="user" className="rounded-circle" width="60" /> */}
        <Avatar
          name={props.profile.userName} round size={30} color='red' />
        <span>
          <h6>{props.profile.userName}</h6>
          <small>{props.profile.email}</small>
        </span>
      </div>
      <DropdownItem className="px-4 py-3">
        <User size={20} />
        &nbsp; My Profile
      </DropdownItem>
      <DropdownItem divider />
    </div>
  );
};

export default connect(mapStateToProps, null)(ProfileDD);
