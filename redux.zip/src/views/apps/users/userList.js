import React, { useEffect } from "react";
import { connect } from "react-redux";
import { Badge, Card, CardBody, Table } from "reactstrap";
import { userList } from "../../auth/redux/actions/user.actions";



const mapStateToProps = (state) => ({
    List: state.userReducer.userList
})

const mapDispatchToProps = (dispatch) => ({
    userList: () => dispatch(userList()),
})
const UserList = (props) => {
    console.log("accessToken:", props.access_token);

    useEffect(() => {
        props.userList()
    }, [])
    console.log("User Lists:", props.List)

    return (
        <Card>
            <CardBody>
                <Table>
                    <thead>
                        <tr>
                            <th>User Name</th>
                            <th>E-mail</th>
                            <th>Mobile Number</th>
                            <th>active</th>
                            <th>Role</th>
                        </tr>
                    </thead>
                    <tbody>
                        {props.List && props.List.map((item) => (
                            <tr>
                                <td>{item.displayName}</td>
                                <td>{item.email}</td>
                                <td>{item.mobileNumber || "NA"}</td>
                                <td>{(item.isActive) ? <Badge color="success">Active</Badge> : <Badge color="danger">Inactive</Badge>}</td>
                                <td>{item.roles[0].roleDisplayName}</td>
                            </tr>
                        ))}
                    </tbody>

                </Table>
            </CardBody>
        </Card >
    )
}

export default connect(mapStateToProps, mapDispatchToProps)(UserList);