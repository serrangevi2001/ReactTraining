import { getToken } from "../../helper/common";
import { SET_USERLISTS } from "../constants/user.constants";
import agent from '../services/agent';

export const setUserList = (userList) => ({
    type: SET_USERLISTS,
    payload: { userList }

})



export const userList = () => (dispatch) => {//eslint-disable-next-line
    getToken(dispatch).then((access_token) => {
        console.log(access_token)

        agent.Auth.userList(access_token)
            .then((list) => {
                console.log(list)
                dispatch(setUserList(list))
            })
    })

}