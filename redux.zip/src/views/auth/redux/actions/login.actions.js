import moment from 'moment';
import { LOGIN_SUCCESS, SET_DETAILS, SET_PROFILES, USER_LOGOUT } from '../constants/login.constants';
import agent from '../services/agent';

// eslint-disable-next-line
export const setDetails = (details) => ({
  type: SET_DETAILS,
  payload: { details },
});

export const SetProfile = (profile) => ({
  type: SET_PROFILES,
  payload: { profile }

})
// eslint-disable-next-line
export const loginSuccess = (email, access_token, expires_in) => ({
  type: LOGIN_SUCCESS,// eslint-disable-next-line
  payload: { email, access_token, expires_in }
})

export const LogOut = () => (dispatch) => {
  dispatch({
    type: USER_LOGOUT
  })
}



export const setTokenDetails = (authData) => {// eslint-disable-next-line
  const { access_token, expires_in, token_type } = authData;// eslint-disable-next-line
  console.log("access Token: ", access_token);
  console.log("expires_in:", expires_in);
  console.log("Token Type:", token_type);
  // eslint-disable-next-line
  const expires = moment().unix() + expires_in;
  console.log(expires);

  localStorage.setItem("access_token", access_token);
  localStorage.setItem("expires_in", expires);
  localStorage.setItem("token_type", token_type)



}

export const userLogin = () => (dispatch, getState) => {

  const currentState = getState();
  console.log('currentState:', currentState);
  const { loginReducer } = currentState;
  console.log('loginReducer:', loginReducer);
  const { details } = loginReducer;
  console.log('details:', details);
  const { email, password } = details;
  console.log('email:', email, 'password', password);

  agent.Auth.login(email, password)
    .then((authData) => {
      console.log(authData);
      setTokenDetails(authData);// eslint-disable-next-line
      const { access_token, expires_in } = authData;// eslint-disable-next-line
      console.log("access Token: ", access_token);// eslint-disable-next-line
      console.log("expires_in:", expires_in);


      agent.Auth.profile(access_token)
        .then((userProfile) => {
          console.log("User Profile:", userProfile)
          dispatch(SetProfile(userProfile));
          dispatch(loginSuccess(userProfile.email, access_token, expires_in))

        })
    });
};
