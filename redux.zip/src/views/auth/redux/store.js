import { createStore, applyMiddleware, compose } from "redux";
import thunk from 'redux-thunk';
import rootReducer from "./reducers/reducers";
import { USER_LOGOUT } from "./constants/login.constants";


const appReducer = (state, action) => {
    console.log("state", state)
    if (action.type === USER_LOGOUT) {
        localStorage.clear();
        state = undefined;
        localStorage.clear("reduxState")
    }
    return rootReducer(state, action);      // main reduce in like state an action
}

const persistedstate = (() => {
    try {
        const state = localStorage.getItem("reduxState");
        return state ? JSON.parse(state) : {};
    }
    catch (e) {
        console.warn("Error parsing localStorage", e)
        return {};
    }
})();


// eslint-disable-next-line
export function configureStore() {// eslint-disable-next-line
    const middlewares = [thunk];
    const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
    const store = createStore(
        appReducer,
        persistedstate,
        composeEnhancers(applyMiddleware(...middlewares)) // Apply middleware
    );

    store.subscribe(() => {
        localStorage.setItem("reduxState", JSON.stringify(store.getState()))
    })

    return store;
}






