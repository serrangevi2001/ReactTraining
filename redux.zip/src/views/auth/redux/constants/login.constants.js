// eslint-disable-next-line
export const SET_DETAILS = 'SET_DETAILS';
export const SET_PROFILES = 'SET_PROFILE';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const USER_LOGOUT = 'USER_LOGOUT';
