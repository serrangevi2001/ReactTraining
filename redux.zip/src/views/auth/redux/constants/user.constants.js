// eslint-disable-next-line
export const SET_USERLISTS = 'SET_USERLISTS';