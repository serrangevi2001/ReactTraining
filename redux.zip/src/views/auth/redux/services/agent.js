import superAgentPromise from 'superagent-promise';
import _superagent from 'superagent';

const superagent = superAgentPromise(_superagent, Promise);
const responseBody = (resp) => resp.body;
console.log(responseBody)
//eslint-disable-next-line
const apiUrl = 'https://api.ecswitchserver.com';
//eslint-disable-next-line
const request = {
  post: (url, body) =>
    superagent
      .post(url, body)
      .set('Content-Type', 'application/x-www-form-urlencoded')//header
      .then(responseBody),

  getWithToken: (url, token) =>
    superagent
      .get(url, token)
      .set("Content-Type", "application/json")
      .set("Authorization", `Bearer ${token}`)
      .then(responseBody),

};



const Auth = {
  login: (email, password) => {
    console.log('email:', email, 'password:', password);

    const formdata = //eslint-disable-next-line
      "username=" +
      encodeURIComponent(email) +
      "&password=" +
      encodeURIComponent(password) +
      "&grant_type=password";

    return request.post(`${apiUrl}/token`, formdata);

  },//eslint-disable-next-line
  profile: (access_token) => {
    return request.getWithToken(`${apiUrl}/api/user/profile`, access_token)

  },
  // eslint-disable-next-line
  userList: (access_token) => {
    return request.getWithToken(`${apiUrl}/odata/userlist`, access_token)
  }

};

export default { Auth };
