import { SET_USERLISTS } from "../constants/user.constants"


const initialState = {
    userList: {},
}

const userReducer = (state = initialState, action) => {
    switch (action.type) {
        case SET_USERLISTS: {
            const { userList } = action.payload;
            console.log(userList);
            return {
                ...state,
                //eslint-disable-next-line
                userList: userList.value,
            }
        }

        default:
            return state

    }
}

export default userReducer;