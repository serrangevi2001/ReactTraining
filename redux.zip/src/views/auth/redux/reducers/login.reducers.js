
import { LOGIN_SUCCESS, SET_DETAILS, SET_PROFILES } from '../constants/login.constants';

const initialState = {
  details: {},
  profile: {},
  email: null,
  access_token: null,
  expires_in: null,
  isAuth: false,
};


const loginReducer = (state = initialState, action) => {

  switch (
  action.type
  ) {
    case SET_DETAILS: {

      const { details } = action.payload;
      console.log('details', details);
      return {
        ...state,
        // eslint-disable-next-line
        details: details,
      };
    }

    case SET_PROFILES: {
      const { profile } = action.payload;
      console.log("user profie:", profile);
      return {
        ...state,
        // eslint-disable-next-line
        profile: profile,


      }
    }

    case LOGIN_SUCCESS: {// eslint-disable-next-line
      const { email, access_token, expires_in } = action.payload; // eslint-disable-next-line
      console.log("email :", email, "access_token", access_token, "expires_in", expires_in);
      return {
        ...state,// eslint-disable-next-line
        email, access_token, expires_in, isAuth: true

      }


    }



    default:
      return state;
  }
};

export default loginReducer;
