import moment from "moment";
// eslint-disable-next-line
export const getToken = () => {
  const accessToken = localStorage.getItem('access_token');
  console.log("accessToken:", accessToken)
  const expiresInSec = localStorage.getItem('expires_in');
  console.log("expiresInSec:", expiresInSec)
  return new Promise((resolve) => {
    const diff = moment.unix(Number(expiresInSec)).diff(moment(), 'minutes');
    console.log(moment.unix(Number(expiresInSec)))
    console.log("diff", diff)
    if (accessToken && diff > 5) {
      console.log("accessToken", accessToken)
      console.log("accessToken && diff >5:", accessToken && diff > 5)
      resolve(accessToken);
    } else {
      console.log('getToken ', diff);
      // eslint-disable-next-line no-unused-expressions
      console.log("accessToken:", accessToken)
      resolve(accessToken);
    }
  });
};






