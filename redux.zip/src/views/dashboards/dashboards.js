import React from 'react'

const dashboards = () => {
  return (
    <div>Welcome to dashboard</div>
  )
}

export default dashboards