import DashCard from '../dashboardCards/DashCard';

const DummyCard = () => {
  return (
    <DashCard title="test" subtitle="test">
      test
    </DashCard>
  );
};

export default DummyCard;
